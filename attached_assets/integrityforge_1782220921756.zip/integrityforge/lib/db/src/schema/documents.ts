import { pgTable, text, serial, timestamp, integer, real, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const documentStatusEnum = pgEnum("document_status", ["pending", "processing", "completed", "failed"]);
export const ownerRoleEnum = pgEnum("owner_role", ["student", "instructor", "admin"]);

export const documentsTable = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  fileType: text("file_type").notNull().default("text"),
  status: documentStatusEnum("status").notNull().default("pending"),
  ownerId: text("owner_id").notNull(),
  ownerRole: ownerRoleEnum("owner_role").notNull().default("student"),
  content: text("content").notNull().default(""),
  overallPlagiarismScore: real("overall_plagiarism_score"),
  overallAiScore: real("overall_ai_score"),
  chunkCount: integer("chunk_count"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertDocumentSchema = createInsertSchema(documentsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documentsTable.$inferSelect;
