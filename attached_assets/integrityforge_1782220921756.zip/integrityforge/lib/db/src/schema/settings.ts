import { pgTable, text, serial, real, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  plagiarismThreshold: real("plagiarism_threshold").notNull().default(0.75),
  aiConfidenceThreshold: real("ai_confidence_threshold").notNull().default(0.75),
  chunkSize: integer("chunk_size").notNull().default(350),
  chunkOverlap: integer("chunk_overlap").notNull().default(50),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({ id: true });
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;
