const archiver = require("archiver");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "../");
const out = "/tmp/integrityforge.zip";

const IGNORE_DIRS = new Set(["node_modules", ".git", "dist", "__pycache__", ".cache", ".local"]);
const IGNORE_FILES = new Set(["pnpm-lock.yaml"]);
const IGNORE_EXTS = [".tsbuildinfo", ".map"];

const output = fs.createWriteStream(out);
const archive = archiver("zip", { zlib: { level: 6 } });

function addDir(dirPath, zipBase) {
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    if (IGNORE_DIRS.has(entry.name)) continue;
    if (IGNORE_FILES.has(entry.name)) continue;
    if (IGNORE_EXTS.some((e) => entry.name.endsWith(e))) continue;
    const full = path.join(dirPath, entry.name);
    const zip = path.join(zipBase, entry.name);
    if (entry.isDirectory()) addDir(full, zip);
    else archive.file(full, { name: zip });
  }
}

output.on("close", () => {
  const mb = (archive.pointer() / 1024 / 1024).toFixed(1);
  console.log("Done — " + out + " (" + mb + " MB)");
});
archive.on("error", (err) => { throw err; });
archive.pipe(output);
addDir(root, "integrityforge");
archive.finalize();
