import { Router } from "express";
import { eq, and } from "drizzle-orm";
import { db, documentsTable, documentChunksTable } from "@workspace/db";
import {
  CreateDocumentBody,
  GetDocumentParams,
  DeleteDocumentParams,
  ListDocumentsQueryParams,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router = Router();

router.get("/documents", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const query = ListDocumentsQueryParams.safeParse(req.query);

  const conditions = [eq(documentsTable.ownerId, userId)];

  let docs = await db.select().from(documentsTable).where(conditions[0]).orderBy(documentsTable.createdAt);

  if (query.success && query.data.status) {
    docs = docs.filter((d) => d.status === query.data.status);
  }

  res.json(docs);
});

router.post("/documents", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const parsed = CreateDocumentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [doc] = await db
    .insert(documentsTable)
    .values({
      title: parsed.data.title,
      fileType: parsed.data.fileType,
      content: parsed.data.content,
      ownerRole: parsed.data.ownerRole,
      ownerId: userId,
      status: "pending",
    })
    .returning();

  res.status(201).json(doc);
});

router.get("/documents/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = GetDocumentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(and(eq(documentsTable.id, params.data.id), eq(documentsTable.ownerId, userId)));

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  res.json(doc);
});

router.delete("/documents/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = DeleteDocumentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [doc] = await db
    .delete(documentsTable)
    .where(and(eq(documentsTable.id, params.data.id), eq(documentsTable.ownerId, userId)))
    .returning();

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
