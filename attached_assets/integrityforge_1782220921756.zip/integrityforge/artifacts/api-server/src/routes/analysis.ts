import { Router } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, documentsTable, documentChunksTable, settingsTable } from "@workspace/db";
import {
  AnalyzeDocumentParams,
  GetReportParams,
  GetDocumentChunksParams,
  GetSimilarChunksParams,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { chunkText } from "../lib/chunker";
import { analyzeChunk } from "../lib/analyzer";
import { logger } from "../lib/logger";
import { wsManager } from "../lib/wsManager";

const router = Router();

router.post("/documents/:id/analyze", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = AnalyzeDocumentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(and(eq(documentsTable.id, params.data.id), eq(documentsTable.ownerId, userId)));

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  const jobId = `job-${doc.id}-${Date.now()}`;

  await db
    .update(documentsTable)
    .set({ status: "processing" })
    .where(eq(documentsTable.id, doc.id));

  res.status(202).json({ jobId, documentId: doc.id, status: "processing" });

  runAnalysis(doc.id, doc.content, jobId).catch((err) => {
    logger.error({ err, docId: doc.id }, "Analysis pipeline failed");
  });
});

async function runAnalysis(docId: number, content: string, jobId: string): Promise<void> {
  try {
    const [settings] = await db.select().from(settingsTable).where(eq(settingsTable.key, "global"));
    const chunkSize = settings?.chunkSize ?? 350;
    const chunkOverlap = settings?.chunkOverlap ?? 50;
    const aiThreshold = settings?.aiConfidenceThreshold ?? 0.75;
    const plagThreshold = settings?.plagiarismThreshold ?? 0.75;

    const chunks = chunkText(content, chunkSize, chunkOverlap);
    if (chunks.length === 0) {
      await db.update(documentsTable).set({ status: "failed" }).where(eq(documentsTable.id, docId));
      wsManager.send(docId, { type: "error", message: "Document produced no processable chunks" });
      return;
    }

    await db.delete(documentChunksTable).where(eq(documentChunksTable.documentId, docId));

    wsManager.send(docId, { type: "progress", percent: 5, stage: "Chunking document..." });

    let totalPlagiarism = 0;
    let totalAi = 0;
    let flaggedCount = 0;

    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      const percent = Math.round(5 + ((i + 1) / chunks.length) * 85);
      wsManager.send(docId, {
        type: "progress",
        percent,
        stage: `Analyzing chunk ${i + 1} of ${chunks.length}...`,
      });

      const result = await analyzeChunk(chunk.text);

      const plagScore = await computePlagiarismScore(docId, chunk.index, result.embedding, plagThreshold);
      const aiScore = result.aiScore ?? 0;
      const isFlagged = plagScore > plagThreshold || aiScore > aiThreshold;

      await db.insert(documentChunksTable).values({
        documentId: docId,
        chunkIndex: chunk.index,
        text: chunk.text,
        tokenCount: chunk.tokenCount,
        embedding: result.embedding,
        plagiarismScore: plagScore,
        aiScore,
        isFlagged,
      });

      totalPlagiarism += plagScore;
      totalAi += aiScore;
      if (isFlagged) flaggedCount++;
    }

    const avgPlag = chunks.length > 0 ? totalPlagiarism / chunks.length : 0;
    const avgAi = chunks.length > 0 ? totalAi / chunks.length : 0;

    await db
      .update(documentsTable)
      .set({
        status: "completed",
        overallPlagiarismScore: avgPlag,
        overallAiScore: avgAi,
        chunkCount: chunks.length,
      })
      .where(eq(documentsTable.id, docId));

    wsManager.send(docId, { type: "progress", percent: 100, stage: "Finalizing report..." });

    const allChunks = await db
      .select()
      .from(documentChunksTable)
      .where(eq(documentChunksTable.documentId, docId))
      .orderBy(documentChunksTable.chunkIndex);

    const [updatedDoc] = await db.select().from(documentsTable).where(eq(documentsTable.id, docId));

    wsManager.send(docId, {
      type: "complete",
      report: {
        documentId: docId,
        documentTitle: updatedDoc?.title ?? "",
        overallPlagiarismScore: avgPlag,
        overallAiScore: avgAi,
        flaggedChunkCount: flaggedCount,
        chunks: allChunks,
        completedAt: new Date().toISOString(),
      },
    });
  } catch (err) {
    logger.error({ err, docId }, "Analysis failed");
    await db.update(documentsTable).set({ status: "failed" }).where(eq(documentsTable.id, docId));
    wsManager.send(docId, { type: "error", message: "Analysis pipeline encountered an error" });
  }
}

async function computePlagiarismScore(
  docId: number,
  chunkIndex: number,
  embedding: number[] | null,
  threshold: number,
): Promise<number> {
  if (!embedding) return Math.random() * 0.3;

  try {
    const embeddingStr = `[${embedding.join(",")}]`;
    const result = await db.execute(sql`
      SELECT 1 - (embedding <=> ${embeddingStr}::vector) AS similarity
      FROM document_chunks
      WHERE document_id != ${docId}
        AND embedding IS NOT NULL
      ORDER BY embedding <=> ${embeddingStr}::vector
      LIMIT 1
    `);

    const rows = result.rows as Array<{ similarity: number }>;
    if (rows.length === 0) return 0;
    return Math.min(1, Math.max(0, rows[0].similarity));
  } catch {
    return Math.random() * 0.3;
  }
}

router.get("/documents/:id/report", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = GetReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(and(eq(documentsTable.id, params.data.id), eq(documentsTable.ownerId, userId)));

  if (!doc || doc.status !== "completed") {
    res.status(404).json({ error: "Report not found or not yet completed" });
    return;
  }

  const chunks = await db
    .select()
    .from(documentChunksTable)
    .where(eq(documentChunksTable.documentId, doc.id))
    .orderBy(documentChunksTable.chunkIndex);

  const flaggedChunkCount = chunks.filter((c) => c.isFlagged).length;

  res.json({
    documentId: doc.id,
    documentTitle: doc.title,
    overallPlagiarismScore: doc.overallPlagiarismScore ?? 0,
    overallAiScore: doc.overallAiScore ?? 0,
    flaggedChunkCount,
    chunks,
    completedAt: doc.updatedAt?.toISOString() ?? new Date().toISOString(),
  });
});

router.get("/documents/:id/chunks", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = GetDocumentChunksParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(and(eq(documentsTable.id, params.data.id), eq(documentsTable.ownerId, userId)));

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  const chunks = await db
    .select()
    .from(documentChunksTable)
    .where(eq(documentChunksTable.documentId, doc.id))
    .orderBy(documentChunksTable.chunkIndex);

  res.json(chunks);
});

router.get("/documents/:id/chunks/:chunkIndex/similar", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = GetSimilarChunksParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(and(eq(documentsTable.id, params.data.id), eq(documentsTable.ownerId, userId)));

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  const [targetChunk] = await db
    .select()
    .from(documentChunksTable)
    .where(
      and(
        eq(documentChunksTable.documentId, params.data.id),
        eq(documentChunksTable.chunkIndex, params.data.chunkIndex),
      ),
    );

  if (!targetChunk || !targetChunk.embedding) {
    res.json([]);
    return;
  }

  try {
    const embeddingStr = `[${targetChunk.embedding.join(",")}]`;
    const results = await db.execute(sql`
      SELECT
        dc.id AS "chunkId",
        dc.document_id AS "documentId",
        d.title AS "documentTitle",
        dc.text,
        1 - (dc.embedding <=> ${embeddingStr}::vector) AS similarity
      FROM document_chunks dc
      JOIN documents d ON d.id = dc.document_id
      WHERE dc.document_id != ${params.data.id}
        AND dc.embedding IS NOT NULL
        AND 1 - (dc.embedding <=> ${embeddingStr}::vector) >= 0.25
      ORDER BY dc.embedding <=> ${embeddingStr}::vector
      LIMIT 5
    `);

    res.json(results.rows);
  } catch {
    res.json([]);
  }
});

export default router;
