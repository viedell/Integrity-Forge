import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, documentsTable, settingsTable } from "@workspace/db";
import { GetRecentActivityQueryParams, UpdateSettingsBody } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router = Router();

router.get("/dashboard/summary", requireAuth, async (_req, res): Promise<void> => {
  const allDocs = await db.select().from(documentsTable);
  const completed = allDocs.filter((d) => d.status === "completed");

  const avgPlagiarism =
    completed.length > 0
      ? completed.reduce((s, d) => s + (d.overallPlagiarismScore ?? 0), 0) / completed.length
      : 0;

  const avgAi =
    completed.length > 0
      ? completed.reduce((s, d) => s + (d.overallAiScore ?? 0), 0) / completed.length
      : 0;

  const highRiskCount = completed.filter(
    (d) => (d.overallPlagiarismScore ?? 0) > 0.75 || (d.overallAiScore ?? 0) > 0.75,
  ).length;

  res.json({
    totalDocuments: allDocs.length,
    completedAnalyses: completed.length,
    avgPlagiarismScore: avgPlagiarism,
    avgAiScore: avgAi,
    statusBreakdown: {
      pending: allDocs.filter((d) => d.status === "pending").length,
      processing: allDocs.filter((d) => d.status === "processing").length,
      completed: completed.length,
      failed: allDocs.filter((d) => d.status === "failed").length,
    },
    highRiskCount,
  });
});

router.get("/dashboard/recent", requireAuth, async (req, res): Promise<void> => {
  const query = GetRecentActivityQueryParams.safeParse(req.query);
  const limit = query.success ? (query.data.limit ?? 10) : 10;

  const docs = await db
    .select()
    .from(documentsTable)
    .orderBy(documentsTable.createdAt)
    .limit(limit);

  res.json(docs.reverse());
});

router.get("/settings", requireAuth, async (_req, res): Promise<void> => {
  const [settings] = await db.select().from(settingsTable).where(eq(settingsTable.key, "global"));

  if (!settings) {
    const [created] = await db
      .insert(settingsTable)
      .values({ key: "global" })
      .returning();
    res.json({
      plagiarismThreshold: created.plagiarismThreshold,
      aiConfidenceThreshold: created.aiConfidenceThreshold,
      chunkSize: created.chunkSize,
      chunkOverlap: created.chunkOverlap,
    });
    return;
  }

  res.json({
    plagiarismThreshold: settings.plagiarismThreshold,
    aiConfidenceThreshold: settings.aiConfidenceThreshold,
    chunkSize: settings.chunkSize,
    chunkOverlap: settings.chunkOverlap,
  });
});

router.patch("/settings", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Partial<{
    plagiarismThreshold: number;
    aiConfidenceThreshold: number;
    chunkSize: number;
    chunkOverlap: number;
  }> = {};

  if (parsed.data.plagiarismThreshold != null) updates.plagiarismThreshold = parsed.data.plagiarismThreshold;
  if (parsed.data.aiConfidenceThreshold != null) updates.aiConfidenceThreshold = parsed.data.aiConfidenceThreshold;
  if (parsed.data.chunkSize != null) updates.chunkSize = parsed.data.chunkSize;
  if (parsed.data.chunkOverlap != null) updates.chunkOverlap = parsed.data.chunkOverlap;

  const existing = await db.select().from(settingsTable).where(eq(settingsTable.key, "global"));

  let result;
  if (existing.length === 0) {
    [result] = await db.insert(settingsTable).values({ key: "global", ...updates }).returning();
  } else {
    [result] = await db.update(settingsTable).set(updates).where(eq(settingsTable.key, "global")).returning();
  }

  res.json({
    plagiarismThreshold: result.plagiarismThreshold,
    aiConfidenceThreshold: result.aiConfidenceThreshold,
    chunkSize: result.chunkSize,
    chunkOverlap: result.chunkOverlap,
  });
});

export default router;
