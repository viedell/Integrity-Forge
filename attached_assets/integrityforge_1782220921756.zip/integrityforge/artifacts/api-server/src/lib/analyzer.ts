import { logger } from "./logger";

export interface AnalysisResult {
  embedding: number[] | null;
  plagiarismScore: number | null;
  aiScore: number | null;
}

const EMBEDDING_DIM = 768;

function randomEmbedding(): number[] {
  const vec = Array.from({ length: EMBEDDING_DIM }, () => Math.random() * 2 - 1);
  const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
  return vec.map((v) => v / norm);
}

function simulateAiScore(text: string): number {
  const aiMarkers = [
    "it is important to note",
    "in conclusion",
    "furthermore",
    "in summary",
    "as a result",
    "it can be seen",
    "this demonstrates",
    "notably",
    "in this context",
    "it should be mentioned",
  ];
  const lower = text.toLowerCase();
  const matches = aiMarkers.filter((m) => lower.includes(m)).length;
  const base = 0.15 + Math.random() * 0.25;
  return Math.min(0.95, base + matches * 0.12);
}

async function getEmbedding(text: string): Promise<number[]> {
  try {
    const ollamaUrl = process.env.OLLAMA_URL || "http://localhost:11434";
    const response = await fetch(`${ollamaUrl}/api/embeddings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "nomic-embed-text", prompt: text }),
      signal: AbortSignal.timeout(5000),
    });
    if (!response.ok) throw new Error(`Ollama responded ${response.status}`);
    const data = (await response.json()) as { embedding: number[] };
    return data.embedding;
  } catch (err) {
    logger.warn({ err }, "Ollama unavailable — using simulated embedding");
    return randomEmbedding();
  }
}

async function getAiScore(text: string): Promise<number> {
  return simulateAiScore(text);
}

export async function analyzeChunk(text: string): Promise<AnalysisResult> {
  const [embedding, aiScore] = await Promise.allSettled([
    getEmbedding(text),
    getAiScore(text),
  ]);

  return {
    embedding: embedding.status === "fulfilled" ? embedding.value : null,
    plagiarismScore: null,
    aiScore: aiScore.status === "fulfilled" ? aiScore.value : null,
  };
}
