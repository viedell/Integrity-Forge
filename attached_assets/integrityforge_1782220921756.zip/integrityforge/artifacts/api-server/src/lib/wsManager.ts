import { WebSocketServer, WebSocket } from "ws";
import type { IncomingMessage } from "http";
import { logger } from "./logger";

class WebSocketManager {
  private wss: WebSocketServer | null = null;
  private connections = new Map<number, Set<WebSocket>>();

  init(server: import("http").Server): void {
    this.wss = new WebSocketServer({ noServer: true });

    server.on("upgrade", (req: IncomingMessage, socket, head) => {
      const url = req.url ?? "";
      const match = url.match(/\/api\/ws\/analysis\/(\d+)/);
      if (!match) {
        socket.destroy();
        return;
      }

      const docId = parseInt(match[1], 10);
      this.wss!.handleUpgrade(req, socket, head, (ws) => {
        logger.info({ docId }, "WebSocket client connected");

        if (!this.connections.has(docId)) {
          this.connections.set(docId, new Set());
        }
        this.connections.get(docId)!.add(ws);

        ws.on("close", () => {
          this.connections.get(docId)?.delete(ws);
          if (this.connections.get(docId)?.size === 0) {
            this.connections.delete(docId);
          }
        });
      });
    });
  }

  send(docId: number, data: unknown): void {
    const clients = this.connections.get(docId);
    if (!clients || clients.size === 0) return;

    const message = JSON.stringify(data);
    for (const ws of clients) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    }
  }
}

export const wsManager = new WebSocketManager();
