export interface TextChunk {
  text: string;
  tokenCount: number;
  index: number;
}

function estimateTokens(text: string): number {
  return Math.ceil(text.split(/\s+/).length * 1.3);
}

function stripBoilerplate(text: string): string {
  const boilerplatePatterns = [
    /^\s*(abstract|introduction|references|bibliography|acknowledgements?)\s*\n/gim,
    /^\s*page\s+\d+\s+of\s+\d+\s*$/gim,
    /^\s*\d+\s*$/gm,
    /copyright\s+©?\s*\d{4}[^\n]*/gi,
    /all\s+rights\s+reserved[^\n]*/gi,
    /submitted\s+(in\s+partial\s+)?fulfillment[^\n]*/gi,
    /university\s+of\s+\w+[^\n]*/gi,
  ];
  let cleaned = text;
  for (const pattern of boilerplatePatterns) {
    cleaned = cleaned.replace(pattern, "");
  }
  return cleaned.replace(/\n{3,}/g, "\n\n").trim();
}

export function chunkText(text: string, targetTokens = 350, overlap = 50): TextChunk[] {
  const cleaned = stripBoilerplate(text);
  const words = cleaned.split(/\s+/).filter(Boolean);

  if (words.length === 0) return [];

  const wordsPerChunk = Math.ceil(targetTokens / 1.3);
  const overlapWords = Math.ceil(overlap / 1.3);

  const chunks: TextChunk[] = [];
  let start = 0;
  let index = 0;

  while (start < words.length) {
    const end = Math.min(start + wordsPerChunk, words.length);
    const chunkWords = words.slice(start, end);
    const chunkText = chunkWords.join(" ");

    chunks.push({
      text: chunkText,
      tokenCount: estimateTokens(chunkText),
      index,
    });

    if (end >= words.length) break;
    start = end - overlapWords;
    index++;
  }

  return chunks;
}
