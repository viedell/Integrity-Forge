import { useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { Switch, Route, Redirect, useLocation, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import Documents from "@/pages/documents";
import Upload from "@/pages/upload";
import DocumentDetail from "@/pages/document-detail";
import Settings from "@/pages/settings";

const queryClient = new QueryClient();

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in .env file");
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "hsl(212 100% 50%)",
    colorForeground: "hsl(210 40% 98%)",
    colorMutedForeground: "hsl(215 20.2% 65.1%)",
    colorDanger: "hsl(0 84% 60%)",
    colorBackground: "hsl(216 28% 9%)",
    colorInput: "hsl(216 28% 12%)",
    colorInputForeground: "hsl(210 40% 98%)",
    colorNeutral: "hsl(216 28% 18%)",
    fontFamily: "'Space Mono', 'Geist', 'Inter', monospace",
    borderRadius: "0.25rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[#0d1117] rounded-sm w-[440px] max-w-full overflow-hidden border border-[#161b22]",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-white text-xl font-bold font-mono tracking-tight",
    headerSubtitle: "text-slate-400 font-mono text-sm",
    socialButtonsBlockButtonText: "text-slate-200 font-mono text-sm",
    formFieldLabel: "text-slate-300 font-mono text-xs uppercase tracking-wider",
    footerActionLink: "text-[#007bff] hover:text-[#3395ff] font-mono",
    footerActionText: "text-slate-400 font-mono text-sm",
    dividerText: "text-slate-500 font-mono text-xs uppercase",
    identityPreviewEditButton: "text-[#007bff] hover:text-[#3395ff]",
    formFieldSuccessText: "text-emerald-400 font-mono text-xs",
    alertText: "text-red-400 font-mono text-xs",
    logoBox: "mb-4",
    logoImage: "h-12 w-auto",
    socialButtonsBlockButton: "bg-[#161b22] border-[#21262d] hover:bg-[#21262d]",
    formButtonPrimary: "bg-[#007bff] hover:bg-[#0056b3] text-white font-mono uppercase tracking-wider text-sm",
    formFieldInput: "bg-[#0d1117] border-[#30363d] text-white font-mono placeholder:text-slate-600 focus:border-[#007bff] focus:ring-1 focus:ring-[#007bff]",
    footerAction: "bg-[#0d1117]",
    dividerLine: "bg-[#21262d]",
    alert: "bg-[#21262d] border border-red-500/50",
    otpCodeFieldInput: "bg-[#0d1117] border-[#30363d] text-white",
    formFieldRow: "mb-4",
    main: "mt-4",
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </div>
  );
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/dashboard" />
      </Show>
      <Show when="signed-out">
        <Landing />
      </Show>
    </>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "SYSTEM ACCESS",
            subtitle: "Authenticate to proceed",
          },
        },
        signUp: {
          start: {
            title: "INITIALIZE ACCT",
            subtitle: "Establish identity credentials",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <Switch>
          <Route path="/" component={HomeRedirect} />
          <Route path="/sign-in/*?" component={SignInPage} />
          <Route path="/sign-up/*?" component={SignUpPage} />
          
          <Route path="/dashboard">
            <Show when="signed-in" fallback={<Redirect to="/sign-in" />}>
              <Dashboard />
            </Show>
          </Route>
          <Route path="/upload">
            <Show when="signed-in" fallback={<Redirect to="/sign-in" />}>
              <Upload />
            </Show>
          </Route>
          <Route path="/documents">
            <Show when="signed-in" fallback={<Redirect to="/sign-in" />}>
              <Documents />
            </Show>
          </Route>
          <Route path="/documents/:id">
            <Show when="signed-in" fallback={<Redirect to="/sign-in" />}>
              <DocumentDetail />
            </Show>
          </Route>
          <Route path="/settings">
            <Show when="signed-in" fallback={<Redirect to="/sign-in" />}>
              <Settings />
            </Show>
          </Route>

          <Route component={NotFound} />
        </Switch>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <TooltipProvider>
        <ClerkProviderWithRoutes />
        <Toaster />
      </TooltipProvider>
    </WouterRouter>
  );
}

export default App;
