import { ProtectedLayout } from "@/components/layout/protected-layout";
import { useListDocuments } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Loader2 } from "lucide-react";
import { format } from "date-fns";

export default function Documents() {
  const { data: documents, isLoading } = useListDocuments();

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed': return <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 font-mono text-[10px] uppercase">Completed</Badge>;
      case 'processing': return <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20 font-mono text-[10px] uppercase animate-pulse">Processing</Badge>;
      case 'failed': return <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/20 font-mono text-[10px] uppercase">Failed</Badge>;
      default: return <Badge variant="outline" className="bg-slate-500/10 text-slate-400 border-slate-500/20 font-mono text-[10px] uppercase">Pending</Badge>;
    }
  };

  const getScoreColor = (score?: number | null) => {
    if (score == null) return "text-slate-500";
    if (score > 0.75) return "text-destructive font-bold";
    if (score > 0.4) return "text-warning font-bold";
    return "text-emerald-400";
  };

  return (
    <ProtectedLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold font-mono text-white tracking-tight uppercase">Document Ledger</h1>
            <p className="text-sm text-muted-foreground font-mono mt-1">Registry of all scanned materials.</p>
          </div>
          <Link href="/upload">
            <Button className="font-mono uppercase text-xs tracking-wider bg-primary hover:bg-primary/90 text-white">
              + New Scan
            </Button>
          </Link>
        </div>

        <div className="border border-border rounded-md bg-card/50 overflow-hidden">
          <Table>
            <TableHeader className="bg-card">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="font-mono text-xs text-muted-foreground uppercase">Document</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground uppercase">Status</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground uppercase text-right">Plagiarism Risk</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground uppercase text-right">AI Prob</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground uppercase text-right">Date</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-32 text-center">
                    <Loader2 className="w-6 h-6 text-primary animate-spin mx-auto" />
                  </TableCell>
                </TableRow>
              ) : documents?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-32 text-center font-mono text-sm text-muted-foreground">
                    No documents found in registry.
                  </TableCell>
                </TableRow>
              ) : (
                documents?.map((doc) => (
                  <TableRow key={doc.id} className="border-border hover:bg-muted/50 transition-colors group">
                    <TableCell className="font-mono text-sm text-slate-200">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-primary opacity-70" />
                        {doc.title}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(doc.status)}</TableCell>
                    <TableCell className={`font-mono text-xs text-right ${getScoreColor(doc.overallPlagiarismScore)}`}>
                      {doc.overallPlagiarismScore != null ? `${(doc.overallPlagiarismScore * 100).toFixed(1)}%` : '--'}
                    </TableCell>
                    <TableCell className={`font-mono text-xs text-right ${getScoreColor(doc.overallAiScore)}`}>
                      {doc.overallAiScore != null ? `${(doc.overallAiScore * 100).toFixed(1)}%` : '--'}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground text-right">
                      {format(new Date(doc.createdAt), "MMM d, HH:mm")}
                    </TableCell>
                    <TableCell className="text-right">
                      <Link href={`/documents/${doc.id}`}>
                        <Button variant="ghost" size="sm" className="font-mono text-[10px] uppercase text-primary hover:text-primary hover:bg-primary/10 h-7 opacity-0 group-hover:opacity-100 transition-opacity">
                          View
                        </Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </ProtectedLayout>
  );
}
