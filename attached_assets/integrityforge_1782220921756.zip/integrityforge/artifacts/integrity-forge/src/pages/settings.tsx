import { useState, useEffect } from "react";
import { ProtectedLayout } from "@/components/layout/protected-layout";
import { useGetSettings, useUpdateSettings, getGetSettingsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Settings as SettingsIcon, Save, Loader2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { data: settings, isLoading } = useGetSettings();
  const updateMutation = useUpdateSettings();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [localSettings, setLocalSettings] = useState({
    plagiarismThreshold: 0.75,
    aiConfidenceThreshold: 0.75,
    chunkSize: 350,
    chunkOverlap: 50
  });

  useEffect(() => {
    if (settings) {
      setLocalSettings({
        plagiarismThreshold: settings.plagiarismThreshold,
        aiConfidenceThreshold: settings.aiConfidenceThreshold,
        chunkSize: settings.chunkSize,
        chunkOverlap: settings.chunkOverlap
      });
    }
  }, [settings]);

  const handleSave = async () => {
    try {
      await updateMutation.mutateAsync({ data: localSettings });
      queryClient.invalidateQueries({ queryKey: getGetSettingsQueryKey() });
      toast({
        title: "Settings Updated",
        description: "Global analysis thresholds have been applied.",
      });
    } catch (err) {
      console.error(err);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update settings.",
      });
    }
  };

  if (isLoading) {
    return (
      <ProtectedLayout>
        <div className="flex justify-center p-20"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>
      </ProtectedLayout>
    );
  }

  return (
    <ProtectedLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <header>
          <h1 className="text-2xl font-bold font-mono text-white tracking-tight uppercase">System Configuration</h1>
          <p className="text-sm text-muted-foreground font-mono mt-1">Adjust core detection engine parameters.</p>
        </header>

        <Card className="bg-card border-border shadow-none">
          <CardHeader className="border-b border-border bg-muted/20">
            <CardTitle className="font-mono text-sm uppercase text-slate-200 flex items-center gap-2">
              <SettingsIcon className="w-4 h-4 text-primary" /> Detection Thresholds
            </CardTitle>
            <CardDescription className="font-mono text-xs">Changes apply to all future document scans. Requires admin privileges.</CardDescription>
          </CardHeader>
          <CardContent className="pt-6 space-y-8">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label className="font-mono text-xs text-slate-300 uppercase">Plagiarism Threshold</Label>
                <span className="font-mono text-xs text-primary bg-primary/10 px-2 py-1 rounded border border-primary/20">
                  {Math.round(localSettings.plagiarismThreshold * 100)}%
                </span>
              </div>
              <Slider 
                value={[localSettings.plagiarismThreshold]} 
                min={0.1} max={0.99} step={0.01}
                onValueChange={([v]) => setLocalSettings(s => ({ ...s, plagiarismThreshold: v }))}
                className="[&>[role=slider]]:border-primary [&>[role=slider]]:bg-primary [&>span]:bg-border [&>span>span]:bg-primary"
              />
              <p className="text-[10px] font-mono text-muted-foreground">Cosine similarity minimum to trigger a plagiarism flag.</p>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label className="font-mono text-xs text-slate-300 uppercase">AI Confidence Threshold</Label>
                <span className="font-mono text-xs text-primary bg-primary/10 px-2 py-1 rounded border border-primary/20">
                  {Math.round(localSettings.aiConfidenceThreshold * 100)}%
                </span>
              </div>
              <Slider 
                value={[localSettings.aiConfidenceThreshold]} 
                min={0.1} max={0.99} step={0.01}
                onValueChange={([v]) => setLocalSettings(s => ({ ...s, aiConfidenceThreshold: v }))}
                className="[&>[role=slider]]:border-primary [&>[role=slider]]:bg-primary [&>span]:bg-border [&>span>span]:bg-primary"
              />
              <p className="text-[10px] font-mono text-muted-foreground">Probability rating required to flag synthetic generation.</p>
            </div>

            <Button 
              onClick={handleSave} 
              disabled={updateMutation.isPending}
              className="w-full font-mono uppercase tracking-widest bg-primary hover:bg-primary/90 text-white mt-4"
            >
              {updateMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Apply Configuration
            </Button>
          </CardContent>
        </Card>
      </div>
    </ProtectedLayout>
  );
}
