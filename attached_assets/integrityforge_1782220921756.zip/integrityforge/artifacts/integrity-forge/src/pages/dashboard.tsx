import { ProtectedLayout } from "@/components/layout/protected-layout";
import { useGetDashboardSummary } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Activity, AlertTriangle, FileCheck, Layers } from "lucide-react";

export default function Dashboard() {
  const { data: summary, isLoading } = useGetDashboardSummary();

  return (
    <ProtectedLayout>
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold font-mono text-white tracking-tight uppercase">System Overview</h1>
          <p className="text-sm text-muted-foreground font-mono mt-1">Real-time telemetrics and analysis status.</p>
        </header>

        {isLoading || !summary ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 bg-card rounded-lg" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard 
              title="Total Documents" 
              value={summary.totalDocuments} 
              icon={Layers} 
              desc="Scanned in repository" 
            />
            <StatCard 
              title="Completed Analyses" 
              value={summary.completedAnalyses} 
              icon={FileCheck} 
              desc="Successfully processed" 
              trend={`${summary.statusBreakdown.processing} in queue`}
            />
            <StatCard 
              title="Avg Plagiarism Risk" 
              value={`${(summary.avgPlagiarismScore * 100).toFixed(1)}%`} 
              icon={Activity} 
              desc="System-wide average" 
              alert={summary.avgPlagiarismScore > 0.5}
            />
            <StatCard 
              title="High Risk Flags" 
              value={summary.highRiskCount || 0} 
              icon={AlertTriangle} 
              desc="Requires manual review" 
              alert={(summary.highRiskCount || 0) > 0}
            />
          </div>
        )}
      </div>
    </ProtectedLayout>
  );
}

function StatCard({ title, value, desc, icon: Icon, alert = false, trend }: any) {
  return (
    <Card className="bg-card border-border shadow-none">
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-xs font-mono font-medium text-muted-foreground uppercase">{title}</CardTitle>
        <Icon className={`h-4 w-4 ${alert ? 'text-destructive' : 'text-primary'}`} />
      </CardHeader>
      <CardContent>
        <div className={`text-2xl font-bold font-mono ${alert ? 'text-destructive' : 'text-white'}`}>
          {value}
        </div>
        <p className="text-xs text-muted-foreground font-mono mt-1">{desc}</p>
        {trend && <p className="text-xs text-primary font-mono mt-1">{trend}</p>}
      </CardContent>
    </Card>
  );
}
