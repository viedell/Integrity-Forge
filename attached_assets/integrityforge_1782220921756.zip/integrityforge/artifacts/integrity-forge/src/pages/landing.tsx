import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ShieldAlert, Activity, CheckCircle2, ChevronRight } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-primary" />
            <span className="font-mono font-bold tracking-widest text-lg uppercase">IntegrityForge</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/sign-in">
              <Button variant="ghost" className="font-mono text-sm uppercase text-muted-foreground hover:text-foreground">Log In</Button>
            </Link>
            <Link href="/sign-up">
              <Button className="font-mono text-sm uppercase bg-primary text-primary-foreground hover:bg-primary/90">Initialize Access</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none opacity-20" style={{ backgroundImage: 'radial-gradient(circle at center, #007bff 0%, transparent 40%)' }}></div>
        
        <div className="relative z-10 max-w-3xl mx-auto space-y-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-mono uppercase tracking-wider mb-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <Activity className="w-3 h-3" />
            Dual-Engine Analysis Active
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white leading-tight animate-in fade-in slide-in-from-bottom-6 duration-700 delay-150">
            Academic verification.<br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">Forensic precision.</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground font-mono max-w-2xl mx-auto leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
            Advanced detection algorithms scanning for structural plagiarism and AI-generated content. Maintain the integrity of institutional research with high-confidence diagnostics.
          </p>
          
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-500">
            <Link href="/sign-up">
              <Button size="lg" className="h-14 px-8 font-mono text-sm uppercase tracking-widest bg-primary text-primary-foreground hover:bg-primary/90 group">
                Commence Scan
                <ChevronRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-16 text-left border-t border-border/50 animate-in fade-in duration-1000 delay-700">
            {[
              { title: "Deep Semantic Analysis", desc: "Cosine similarity across millions of vectors." },
              { title: "AI Signature Detection", desc: "Identifying synthetic text generation patterns." },
              { title: "Granular Diff Views", desc: "Exact chunk-level evidence side-by-side." }
            ].map((f, i) => (
              <div key={i} className="p-6 rounded-lg border border-border bg-card/30">
                <CheckCircle2 className="w-5 h-5 text-primary mb-3" />
                <h3 className="text-sm font-mono font-bold text-white uppercase mb-2">{f.title}</h3>
                <p className="text-xs font-mono text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
