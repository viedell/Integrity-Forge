import { useState } from "react";
import { ProtectedLayout } from "@/components/layout/protected-layout";
import { useCreateDocument, useAnalyzeDocument, getGetDocumentQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { UploadCloud, Loader2 } from "lucide-react";

export default function Upload() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [role, setRole] = useState<"student" | "instructor" | "admin">("student");
  
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createMutation = useCreateDocument();
  const analyzeMutation = useAnalyzeDocument();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    try {
      const doc = await createMutation.mutateAsync({
        data: {
          title,
          content,
          fileType: "text/plain",
          ownerRole: role
        }
      });

      // Trigger analysis right after creation
      await analyzeMutation.mutateAsync({ id: doc.id });
      
      // Invalidate queries to update lists
      queryClient.invalidateQueries({ queryKey: getGetDocumentQueryKey(doc.id) });
      
      setLocation(`/documents/${doc.id}`);
    } catch (err) {
      console.error("Failed to submit document:", err);
    }
  };

  const isSubmitting = createMutation.isPending || analyzeMutation.isPending;

  return (
    <ProtectedLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <header>
          <h1 className="text-2xl font-bold font-mono text-white tracking-tight uppercase">Submit Material</h1>
          <p className="text-sm text-muted-foreground font-mono mt-1">Input text for integrity analysis.</p>
        </header>

        <Card className="bg-card border-border shadow-none">
          <CardHeader className="border-b border-border bg-muted/20">
            <CardTitle className="font-mono text-sm uppercase text-slate-200">Submission Form</CardTitle>
            <CardDescription className="font-mono text-xs">All submissions are logged and hashed permanently.</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label className="font-mono text-xs text-slate-400 uppercase">Document Title</Label>
                <Input 
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Final Dissertation Chapter 1"
                  className="font-mono bg-background border-border focus-visible:ring-primary"
                  required
                  disabled={isSubmitting}
                />
              </div>

              <div className="space-y-2">
                <Label className="font-mono text-xs text-slate-400 uppercase">Submitter Role</Label>
                <Select value={role} onValueChange={(val: any) => setRole(val)} disabled={isSubmitting}>
                  <SelectTrigger className="font-mono bg-background border-border text-slate-200">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border font-mono text-sm">
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="instructor">Instructor</SelectItem>
                    <SelectItem value="admin">Administrator</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="font-mono text-xs text-slate-400 uppercase">Raw Text Content</Label>
                <Textarea 
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Paste contents here for analysis..."
                  className="min-h-[300px] font-mono text-sm bg-background border-border focus-visible:ring-primary resize-y"
                  required
                  disabled={isSubmitting}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full font-mono uppercase tracking-widest bg-primary hover:bg-primary/90 text-white"
                disabled={isSubmitting || !title || !content}
              >
                {isSubmitting ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...</>
                ) : (
                  <><UploadCloud className="mr-2 h-4 w-4" /> Initialize Scan</>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </ProtectedLayout>
  );
}
