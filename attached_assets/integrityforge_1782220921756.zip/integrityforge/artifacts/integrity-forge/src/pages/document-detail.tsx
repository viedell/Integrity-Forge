import { useState, useEffect } from "react";
import { ProtectedLayout } from "@/components/layout/protected-layout";
import { useGetDocument, useGetReport, useGetSimilarChunks, getGetDocumentQueryKey } from "@workspace/api-client-react";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Activity, Database, Crosshair, X, Loader2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "react-day-picker";

export default function DocumentDetail() {
  const { id } = useParams<{ id: string }>();
  const docId = parseInt(id || "0", 10);
  const queryClient = useQueryClient();

  const { data: document, isLoading: docLoading } = useGetDocument(docId, {
    query: { enabled: !!docId, queryKey: getGetDocumentQueryKey(docId) }
  });

  const { data: report, isLoading: reportLoading, refetch: refetchReport } = useGetReport(docId, {
    query: { enabled: document?.status === "completed" }
  });

  const [wsProgress, setWsProgress] = useState(0);
  const [wsStage, setWsStage] = useState("");
  const [selectedChunk, setSelectedChunk] = useState<number | null>(null);

  // WebSocket for live updates
  useEffect(() => {
    if (!document) return;
    if (document.status === "completed" || document.status === "failed") return;

    const ws = new WebSocket(`ws://${window.location.host}/api/ws/analysis/${docId}`);
    
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "progress") {
          setWsProgress(data.percent);
          setWsStage(data.stage);
        } else if (data.type === "complete") {
          queryClient.invalidateQueries({ queryKey: getGetDocumentQueryKey(docId) });
          refetchReport();
        }
      } catch (e) {
        console.error("WS parse error", e);
      }
    };

    return () => ws.close();
  }, [document?.status, docId, queryClient, refetchReport]);

  const { data: similarChunks, isLoading: similarLoading } = useGetSimilarChunks(docId, selectedChunk ?? 0, {
    query: { enabled: selectedChunk !== null }
  });

  if (docLoading) {
    return (
      <ProtectedLayout>
        <div className="space-y-4">
          <Skeleton className="h-10 w-1/3 bg-card" />
          <Skeleton className="h-64 w-full bg-card" />
        </div>
      </ProtectedLayout>
    );
  }

  if (!document) {
    return <ProtectedLayout><div className="text-destructive font-mono">Document not found</div></ProtectedLayout>;
  }

  const isAnalyzing = document.status === "pending" || document.status === "processing";

  return (
    <ProtectedLayout>
      <div className="flex gap-6 h-[calc(100vh-8rem)]">
        {/* Main Document View */}
        <div className={`flex-1 flex flex-col min-w-0 ${selectedChunk !== null ? 'pr-0' : ''} transition-all duration-300`}>
          <header className="mb-6 flex justify-between items-end">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-2xl font-bold font-mono text-white tracking-tight uppercase truncate">{document.title}</h1>
                <Badge variant="outline" className={`font-mono text-[10px] uppercase ${
                  document.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                  isAnalyzing ? 'bg-blue-500/10 text-blue-400 border-blue-500/20 animate-pulse' :
                  'bg-red-500/10 text-red-400 border-red-500/20'
                }`}>
                  {document.status}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground font-mono">ID: {document.id} | Role: {document.ownerRole.toUpperCase()}</p>
            </div>
            
            {document.status === "completed" && report && (
              <div className="flex gap-4">
                <ScoreGauge label="Plagiarism" score={report.overallPlagiarismScore} />
                <ScoreGauge label="AI Gen" score={report.overallAiScore} />
              </div>
            )}
          </header>

          <Card className="flex-1 bg-card border-border shadow-none overflow-hidden flex flex-col">
            <CardHeader className="border-b border-border bg-muted/20 py-3">
              <CardTitle className="font-mono text-xs uppercase text-slate-300 flex items-center gap-2">
                <Crosshair className="w-4 h-4 text-primary" /> Analysis Viewer
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-y-auto bg-background/50">
              {isAnalyzing ? (
                <div className="h-full flex flex-col items-center justify-center p-10 space-y-6">
                  <Activity className="w-12 h-12 text-primary animate-pulse" />
                  <div className="w-full max-w-md space-y-2">
                    <div className="flex justify-between text-xs font-mono text-muted-foreground uppercase">
                      <span>{wsStage || "Initializing..."}</span>
                      <span>{wsProgress}%</span>
                    </div>
                    <Progress value={wsProgress} className="h-1 bg-border" indicatorClassName="bg-primary transition-all" />
                  </div>
                </div>
              ) : report ? (
                <div className="p-6 font-mono text-sm leading-relaxed text-slate-300 space-y-2">
                  {report.chunks.map((chunk, idx) => {
                    const isFlagged = chunk.isFlagged || (chunk.plagiarismScore && chunk.plagiarismScore > 0.75) || (chunk.aiScore && chunk.aiScore > 0.75);
                    return (
                      <span 
                        key={chunk.id} 
                        onClick={() => isFlagged ? setSelectedChunk(chunk.chunkIndex) : null}
                        className={`inline transition-colors duration-200 ${
                          isFlagged 
                            ? selectedChunk === chunk.chunkIndex 
                              ? 'bg-primary/40 text-white cursor-pointer border-b border-primary relative z-10' 
                              : 'bg-primary/20 hover:bg-primary/30 cursor-pointer border-b border-primary/50'
                            : ''
                        }`}
                        title={isFlagged ? `Plagiarism: ${((chunk.plagiarismScore||0)*100).toFixed(0)}% | AI: ${((chunk.aiScore||0)*100).toFixed(0)}%` : undefined}
                        style={{ animationDelay: `${idx * 20}ms` }}
                      >
                        {chunk.text}{" "}
                      </span>
                    );
                  })}
                </div>
              ) : (
                <div className="p-6 text-center text-muted-foreground font-mono text-sm">Report data unavailable.</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Side Panel for Diff */}
        {selectedChunk !== null && (
          <div className="w-[400px] flex flex-col animate-in slide-in-from-right-8 duration-300">
            <Card className="flex-1 bg-card border-border shadow-2xl overflow-hidden flex flex-col border-l-4 border-l-primary rounded-l-none rounded-r-md">
              <CardHeader className="border-b border-border bg-muted/20 py-3 flex flex-row items-center justify-between sticky top-0 z-10">
                <CardTitle className="font-mono text-xs uppercase text-slate-200 flex items-center gap-2">
                  <Database className="w-4 h-4 text-primary" /> Matches (Chunk #{selectedChunk})
                </CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setSelectedChunk(null)} className="h-6 w-6 text-muted-foreground hover:text-white">
                  <X className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent className="p-4 flex-1 overflow-y-auto space-y-4">
                {similarLoading ? (
                  <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>
                ) : similarChunks?.length ? (
                  similarChunks.map((match, i) => (
                    <div key={i} className="border border-border rounded bg-background p-3 space-y-3">
                      <div className="flex justify-between items-center pb-2 border-b border-border/50">
                        <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider truncate max-w-[200px]" title={match.documentTitle}>
                          Source: {match.documentTitle}
                        </span>
                        <Badge variant="outline" className={`font-mono text-[10px] ${match.similarity > 0.8 ? 'text-destructive border-destructive/30 bg-destructive/10' : 'text-warning border-warning/30 bg-warning/10'}`}>
                          {(match.similarity * 100).toFixed(1)}% Match
                        </Badge>
                      </div>
                      <p className="text-xs font-mono text-slate-300 bg-muted/30 p-2 rounded border border-border/50">
                        {match.text}
                      </p>
                    </div>
                  ))
                ) : (
                  <div className="text-center p-8 text-muted-foreground font-mono text-xs uppercase flex flex-col items-center">
                    <AlertTriangle className="w-8 h-8 mb-2 opacity-50 text-warning" />
                    No exact source chunks found.<br/>Likely synthetic/AI origin.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </ProtectedLayout>
  );
}

function ScoreGauge({ label, score }: { label: string, score: number }) {
  const isHighRisk = score > 0.75;
  const isWarn = score > 0.4;
  const colorClass = isHighRisk ? 'text-destructive' : isWarn ? 'text-warning' : 'text-emerald-400';
  const displayScore = (score * 100).toFixed(1);

  return (
    <div className="bg-card border border-border rounded px-4 py-2 flex flex-col items-end min-w-[120px]">
      <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">{label}</span>
      <span className={`text-xl font-bold font-mono ${colorClass}`}>{displayScore}%</span>
    </div>
  );
}
