# IntegrityForge

Academic integrity platform that detects plagiarism via semantic vector search and AI-generated content via heuristic scoring. Features Clerk RBAC, live WebSocket analysis progress, and chunk-level forensic diff overlay.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 + WebSockets (ws)
- DB: PostgreSQL + pgvector + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- Auth: Clerk (managed, RBAC via metadata)
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Frontend: React + Vite + Tailwind v4 + Wouter + Radix UI

## Where things live

- `lib/api-spec/openapi.yaml` — source of truth for all API endpoints
- `lib/api-zod/src/generated/api.ts` — generated Zod schemas
- `lib/api-react/src/generated/` — generated React Query hooks (Orval)
- `lib/db/src/schema/` — Drizzle table definitions (documents, documentChunks, settings)
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/api-server/src/lib/` — analyzer, chunker, wsManager, auth
- `artifacts/integrity-forge/src/pages/` — all frontend pages

## Architecture decisions

- **Dual-engine analysis**: Ollama (semantic embeddings) + heuristic AI scoring run in parallel per chunk; graceful fallback to simulated embeddings when Ollama is unavailable.
- **Chunk-based diff**: Documents are split into ~350-token chunks with 50-token overlap; each chunk gets independent plagiarism + AI scores stored in `document_chunks`.
- **pgvector HNSW index**: Cosine similarity search uses an HNSW index (`m=16, ef_construction=64`) on the 768-dim embedding column.
- **WebSocket progress**: Analysis runs async after HTTP 202; live progress events pushed to `/api/ws/analysis/{id}` WebSocket clients.
- **OpenAPI contract-first**: All routes derived from `openapi.yaml`; Zod validation on both client (hooks) and server (route handlers).

## Product

- Landing page → sign in/up via Clerk
- Dashboard: aggregate stats (total docs, avg plagiarism/AI scores, high-risk count)
- Documents ledger: list all submissions with risk badges
- Upload: submit text content for analysis
- Document Detail: forensic view with live WebSocket progress bar, per-chunk score overlay, and similar-chunk diffing
- Settings: configure plagiarism threshold, AI confidence threshold, chunk size, and overlap

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after any change to `openapi.yaml` before touching route handlers.
- `GetSimilarChunks` uses path params only (`/documents/{id}/chunks/{chunkIndex}/similar`) — do not add query params with same prefix.
- pgvector HNSW index created via raw SQL (not Drizzle migration); re-run if DB is dropped.
- WebSocket upgrade is handled in `index.ts` via `http.Server`, not Express middleware.
- `pnpm --filter @workspace/db run push` uses `drizzle-kit push` (dev only, not for prod migrations).

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
